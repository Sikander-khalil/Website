<?php

function load_stylesheets()

{



wp_enqueue_style('bootstrap', get_stylesheet_directory_uri().' /css/bootstrap.min.css');

wp_enqueue_style('style', get_stylesheet_directory_uri().' /style.css');


}
add_action('wp_enqueue_scripts','load_stylesheets');




function include_jquery()
{


wp_enqueue_script('jquery', get_template_directory_uri().' /js/jquery-3.1.1.min.js', '', 1, true);
add_action('wp_enqueue_scripts','jquery');
}
add_action('wp_enqueue_scripts','include_jquery');




function loadjs()
{

    wp_enqueue_script('customjs', get_stylesheet_directory_uri().' /js/scripts.js', '', 1, true);


}
add_action('wp_enqueue_scripts','loadjs');


add_theme_support('menus');
add_theme_support('post-thumbnails');

register_nav_menus(

array(

'top-menu' => __('Primary Menu', 'theme'),


)

);

add_image_size('smallest', 300, 300, true);
add_image_size('largest', 800, 800, true);

function selected_class($classes, $item){
	if(in_array('current-menu-item', $classes)) {
		$classes[] = 'selected';
	}
	return $classes;
}
add_filter('nav_menu_css_class', 'selected_class', 10,2);

function custom_siderbar(){
	$arg = 
		array(
        'name'          => __( 'Left-sidebar', 'textdomain' ),
        'id'            => 'sidebar-1',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_widget' => '<div class="sidebar">
          <div class="sidebar_top"></div>
          <div class="sidebar_item">',
        'after_widget'  => '</div>
          <div class="sidebar_base"></div>
        </div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ); 
	register_sidebar($arg);


	$arg_footer = 
		array(
        'name'          => __( 'Footer', 'textdomain' ),
        'id'            => 'footer-1',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'textdomain' ),
        'before_widget' => '<div>',
        'after_widget'  => '</div>
          <div class="sidebar_base"></div>
        </div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ); 
	register_sidebar($arg_footer);


}
add_action( 'widgets_init', 'custom_siderbar' );
function themename_custom_header_setup() {
    $defaults = array(
        // Default Header Image to display
        'default-image'         => get_template_directory_uri() . '/images/headers/default.jpg',
        // Display the header text along with the image
        'header-text'           => false,
        // Header text color default
        'default-text-color'        => '000',
        // Header image width (in pixels)
        'width'             => 1000,
        // Header image height (in pixels)
        'height'            => 198,
        // Header image random rotation default
        'random-default'        => false,
        // Enable upload of image file in admin 
        'uploads'       => false,
        // function to be called in theme head section
        'wp-head-callback'      => 'wphead_cb',
        //  function to be called in preview page head section
        'admin-head-callback'       => 'adminhead_cb',
        // function to produce preview markup in the admin screen
        'admin-preview-callback'    => 'adminpreview_cb',
        );
}
add_action( 'after_setup_theme', 'themename_custom_header_setup' );

add_theme_support( 'post-thumbnails' );

add_theme_support( 'custom-logo' );


add_theme_support( 'custom-header' );

?>