<!DOCTYPE html>
<html>
          <head>

          <title><?php echo get_bloginfo('name'); ?> | <?php echo get_bloginfo('description'); ?></title>
  <meta name="description" content="website description" />
  <meta name="keywords" content="website keywords, website keywords" />
  <meta http-equiv="content-type" content="text/html; charset=windows-1252" />

<link rel="profile" href="https://gmpg.org/xfn/11">
          <?php wp_head();?>
          <link href="<?php bloginfo('template_url'); ?>/style.css" rel="stylesheet">
         </head>


        
       

<header class="sticky-top">
            
<body <?php body_class();?>>    

    
<div class="logo">
    <?php 
    if(function_exists( 'the_custom_logo' )){
        the_custom_logo();
    }
   
?>
<div>
<div class="container">
<h1><?php the_title();?></h1>

    <nav class="mythirdclass">
   
<li class="myforthclass">
<div class="menubutton">
<?php wp_nav_menu (


array(
    'theme_location' => 'top-menu',
    'menu_class' => 'navigation'
)

);?>
</div>
</li>

</nav>

</div>
<div id="content_header"></div>
</header>
</body>
</html>